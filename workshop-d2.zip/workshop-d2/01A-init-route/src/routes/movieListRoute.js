import express from 'express';

const router = express.Router();

// API - 5 Get All Movie List

// API - 6 Get Movie List By ID

// API - 7 Create Movie List

// API - 8 Update Movie List

// API - 17 Delete Movie List (Soft Delete)

// API - 8  Add movie to movie list

// API - 16  Remove movie from movie list

export default router;
