import express from 'express';

const router = express.Router();

// API - 1 Get All Users

// API - 2 Get User By ID

// API - 14 Delete User By ID (Soft Delete)

export default router;
