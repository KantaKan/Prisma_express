import express from 'express';

const router = express.Router();

// API - 3 Get All Movie

// API - 4 Get Movie By ID

// API - 9 Create Movie

// API - 21 Update Movie

// API - 15 Delete Movie (Soft Delete)

// API - 19 Restore Movie

export default router;
