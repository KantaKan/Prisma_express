import express from 'express';

const router = express.Router();

// API - 22 Get All Review By Movie ID

// API - 23 Get Review By ID and Movie ID

// API - 24 Create Review

// API - 25 Update Review

// API - 26 Delete Review

export default router;
